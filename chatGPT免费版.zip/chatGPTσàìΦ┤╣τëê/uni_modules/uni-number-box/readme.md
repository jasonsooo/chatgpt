

## NumberBox 数字输入框
> **组件名：uni-number-box**
> 代码块： `uNumberBox`


带加减按钮的数字输入框。

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-number-box)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 


