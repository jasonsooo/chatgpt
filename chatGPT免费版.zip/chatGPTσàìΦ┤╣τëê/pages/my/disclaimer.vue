<template>
	<view style="padding: 10rpx 30rpx 100rpx 30rpx;">
		<u-parse :content="config.base_disclaimer"></u-parse>
	</view>
</template>

<script>
</script>

<style>
</style>
